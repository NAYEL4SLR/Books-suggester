﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Tipsmaskinen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      
        private void Form1_Load(object sender, EventArgs e)
        {
            Import.ExtractBooks();
        }
        private void btn_tipsa_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Import.library.Count; i++)
            {
                if (Import.library[i].CheckAvailability())
                {
                    textBox1.Text = Import.library[i].ToString();
                    Import.library.RemoveAt(i);
                }
            }
        }
    }
}


