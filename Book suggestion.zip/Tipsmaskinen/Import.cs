﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Tipsmaskinen
{
    static class Import
    {
        internal static List<Book> library = new List<Book>();
        public static void ExtractBooks()
        {
            StreamReader sr = new StreamReader(Application.StartupPath +
                                "\\texter.txt", Encoding.Default, true);
            List<string> txt_file = new List<string>();
            string temp;
            while ((temp = sr.ReadLine()) != null)
            {
                txt_file.Add(temp);
            }
            sr.Close();
            List<string[]> books = new List<string[]>();
            for (int i = 0; i < txt_file.Count; i++)
            {
                books.Add(txt_file[i].Split(new string[] { "###" }
                                        , StringSplitOptions.None));
            }
            SortOutBooks(library);
        }

        static private void SortOutBooks(List<Book> library)
        {
            List<string[]> books = new List<string[]>();
            foreach (string[] stringArray in books)
            {
                library.Add(new Book(stringArray[0], stringArray[1]
                    , stringArray[2], bool.Parse(stringArray[3])));
            }
        }
    }
}
