﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipsmaskinen
{
    class Book
    {
        private string Title;
        private string Writer;
        private string Genre;
        private bool Available;
        public Book(string title, string writer, string genre
                                            , bool available)
        {
            Title = title;
            Writer = writer;
            Genre = genre;
            Available = available;
        }
        public override string ToString()
        {
            return $"{Title}   Author: {Writer}  +  " +
                    $"{Genre}";
        }
        public bool CheckAvailability()
        {
            return Available;
        }
    }
}
